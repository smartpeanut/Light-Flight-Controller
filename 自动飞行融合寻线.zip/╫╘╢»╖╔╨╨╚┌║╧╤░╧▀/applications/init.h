#ifndef _INIT_H_
#define _INIT_H_

#include "stm32f4xx.h"

u8 All_Init(void);
extern u8 Init_Finish;
#endif
